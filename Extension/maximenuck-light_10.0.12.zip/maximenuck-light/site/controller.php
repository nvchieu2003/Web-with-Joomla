<?php
// No direct access
defined('CK_LOADED') or die;

include_once(JPATH_ADMINISTRATOR . '/components/com_maximenuck/controller.php');