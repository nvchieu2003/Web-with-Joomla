<?php
namespace Maximenuck;

defined('_JEXEC') or die;

class CKInput extends  \JInput {
	
}
