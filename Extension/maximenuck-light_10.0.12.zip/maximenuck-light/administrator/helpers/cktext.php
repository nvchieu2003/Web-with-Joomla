<?php
namespace Maximenuck;

defined('_JEXEC') or die;

class CKText extends \JText {
	
}
