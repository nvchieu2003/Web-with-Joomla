<?php
namespace Maximenuck;

defined('_JEXEC') or die;

class CKUri extends \JUri {
	
}
