<?php
// No direct access
defined('_JEXEC') or die('Restricted access');
?>
<?php echo $this->loadTemplate('mainmenu'); ?>
<?php echo $this->loadTemplate('edition'); ?>
<?php echo $this->loadTemplate('importexport'); ?>
