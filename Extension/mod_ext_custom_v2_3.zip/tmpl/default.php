<?php
/*
# ------------------------------------------------------------------------
# Extensions for Joomla 2.5.x - Joomla 3.x - Joomla 4.x
# ------------------------------------------------------------------------
# Copyright (C) 2011-2020 Eco-Joom.com. All Rights Reserved.
# @license - PHP files are GNU/GPL V2.
# Author: Eco-Joom.com
# Author: Makeev Vladimir
#Author email: v.v.makeev@icloud.com
# Websites:  http://eco-joom.com
# Date modified: 05/05/2020 - 13:00
# ------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die;
?>
<div class="mod_ext_custom <?php echo $moduleclass_sfx ?>">
	<?php echo $html; ?>
	<div style="clear:both;"></div>
</div>